from .cCore import Vec3, Matrix


def array(a):
    return Vec3(*a)


BLACK = Vec3(0, 0, 0)
