import pygame

pygame.font.init()

HELVETICA_XSMALL = pygame.font.SysFont("Helvetica", 20)
